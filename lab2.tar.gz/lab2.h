///
// Eric Aguirre
// 861174273
// 4/21/15
///
#ifndef LAB2_H
#define LAB2_H
#include <forward_list>
#include <iostream>

using namespace std;

int primeCount( forward_list<int> lst );

bool isPrime(int i );

template <typename Type>
void listCopy( forward_list<Type> L, forward_list<Type>& P );

template <typename Type>
void printLots (forward_list<Type> L, forward_list<int> P);

template <class T>
struct Node
{
    T data;
    Node<T> *next;
    Node( T data ) : data(data), next(0) {}
};

template <class T>
class List
{
    private:
        Node<T> *head;
        int size;
    public:
        List() : head(0), size(0) {}
        
        ~List()
        {
            while (head != 0)
            {
                Node<T> *temp = head;
                head = head->next;
                delete temp;
                --size;
            }
        }
        
        void push_front( T value )
        {
            Node<T> *temp = new Node<T>(value);
            temp->next = head;
            head = temp;
            ++size;
            return;
        }
        
        void elementSwap(int pos)
        {
            if (pos + 1 >= size || pos < 0) // bounds check
            {
                cout << "Error" << endl;
                return;
            }
            Node<T> *temp = head;
            Node<T> *swap = head->next;
            if (pos == 0) // swap head and head->next and their next pointers
            {
                head = swap;
                temp->next = swap->next;
                swap->next = temp;
            }
            else
            {
                Node<T> *before;
                for (int i = 0; i < pos; ++i) // iterate until at the position
                {
                    before = temp;
                    temp = temp->next;
                    swap = swap->next;
                }
                // Swap same as before but point the node before to swap
                temp->next = swap->next;  
                swap->next = temp;
                before->next = swap;
            }
            return;
        }
        
        void display() const
        {
            if (head == 0)
            {
                cout << "Nothing to display" << endl;
                return;
            }
            cout << head->data;
            Node<T> *temp = head->next;
            while(temp != 0)
            {
                cout << " " << temp->data;
                temp = temp->next;
            }
            cout << endl;
            return;
        }
        
};

#endif