///
// Eric Aguirre
// 861174273
// 4/21/15
///
#include "lab2.h"
#include <forward_list>
#include <cmath>
#include <iostream>

using namespace std;

bool isPrime(int i )
{
    // cout << i << endl;
    if(i < 2) // 0,1 not prime
    {
        // cout << i << "< 2 not" << endl;
        return false;
    }
    if(i == 2) //2 is
    {
        // cout << i << " = 2 prime" << endl;
        return true;
    }
    if(i % 2 == 0) //evens not
    {
        // cout << i << " is even not" << endl;
        return false;
    }
    for(int check = 3; pow(check, 2)<=i; check+=2) // all odds less than sqrt i
    {
        if(i % check == 0 ) 
        {
            // cout << i << "not" << endl;
            return false;
        }
    }
    // cout << i << "prime" << endl;
    return true;
}
int primeCount( forward_list<int> lst )
{
    static int count = 0; //counter
    if(lst.empty())
    {
        return 0;
    }
    // cout << lst.front() << endl;
    if(isPrime(lst.front()))
    {
        ++count;
    }
    lst.pop_front();
    primeCount(lst);
    return count;
}

template <typename Type>
void listCopy(forward_list<Type> L, forward_list<Type>& P)
{
    if (L.empty()) return;
    if (!P.empty())
    {
        forward_list<Type> temp;
        while (!P.empty()) // copy P into temp backwards
        {
            temp.push_front(P.front());
            P.pop_front();
        }
        while (!L.empty()) // copy L into P backwards
        {
            P.push_front(L.front());
            L.pop_front();
        }
        while (!temp.empty()) // copy temp back into P
        {
            P.push_front(temp.front());
            temp.pop_front();
        }
    }
    else
    {
        while (!L.empty())
        {
            P.push_front(L.front());
            L.pop_front();
        }
    }
    return;
}

template <typename Type>
void printLots (forward_list<Type> L, forward_list<int> P)
{
    if (L.empty()) //End of list(P out of bounds)
    {
        cout << "Error out of bounds." << endl;
        return;
    }
    if (P.empty())
    {
        return;
    }
    static int i = 0; // Counter
    if (i == P.front()) // If list number matches counter pop both
    {
        cout << L.front() << " ";
        P.pop_front();
        L.pop_front();
        ++i;
        printLots(L, P);
    }
    else //else pop only L
    {
        L.pop_front();
        ++i;
        printLots(L, P);
    }
    return;
}

int main() {
    forward_list<int> test1 = {2, 3, 5, 7, 11, 13, 17};
    cout << primeCount(test1) << endl;
    forward_list<int> test2 = {5, 7, 8, 9};
    
    List<int> l1;
    l1.push_front(4);
    l1.push_front(5);
    l1.push_front(6);
    l1.push_front(7);
    l1.push_front(8);
    l1.push_front(9); // 9 8 7 6 5 4
    l1.display();
    l1.elementSwap(0); // 8 9 7 6 5 4
    l1.display();
    l1.elementSwap(3); // 8 9 7 5 6 4
    l1.display();
    l1.elementSwap(5);
    l1.elementSwap(6);
    
    listCopy(test2, test1); //Normal test
    for(forward_list<int>::iterator it = test1.begin(); it != test1.end(); ++it)
    {
        cout << *it << " ";
    }
    cout << endl;
    
    forward_list<int> test3;
    listCopy(test2, test3); //Empty test
    for(forward_list<int>::iterator it = test3.begin(); it != test3.end(); ++it)
    {
        cout << *it << " ";
    }
    cout << endl;
    
    forward_list<char> test4 = {'a', 'b', 'c', 'd', 'e'};
    forward_list<int> index = {0, 1, 3, 4, 5};
    printLots(test4, index);
    
    forward_list<char> test5 = {'a', 'b', 'c', 'd', 'e'};
    listCopy(test4, test5); // char test
    for(forward_list<char>::iterator it =test5.begin(); it != test5.end(); ++it)
    {
        cout << *it << " ";
    }
    cout << endl;
    return 0;
}